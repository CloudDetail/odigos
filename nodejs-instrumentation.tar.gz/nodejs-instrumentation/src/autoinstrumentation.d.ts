export {};
//# sourceMappingURL=autoinstrumentation.d.ts.map