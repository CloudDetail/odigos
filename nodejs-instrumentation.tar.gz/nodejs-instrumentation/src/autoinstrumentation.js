"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const auto_instrumentations_node_1 = require("@opentelemetry/auto-instrumentations-node");
const exporter_trace_otlp_grpc_1 = require("@opentelemetry/exporter-trace-otlp-grpc");
const sdk_node_1 = require("@opentelemetry/sdk-node");
const sdk = new sdk_node_1.NodeSDK({
    autoDetectResources: true,
    instrumentations: [(0, auto_instrumentations_node_1.getNodeAutoInstrumentations)()],
    traceExporter: new exporter_trace_otlp_grpc_1.OTLPTraceExporter(),
});
sdk.start();
//# sourceMappingURL=autoinstrumentation.js.map